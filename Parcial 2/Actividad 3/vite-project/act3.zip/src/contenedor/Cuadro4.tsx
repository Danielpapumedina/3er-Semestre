import "../Style/Cuadro4.css"

const Cuadro4 = () => {
return(
    <>
    <ol>
        <li>Elemento 001</li>
        <li>Elemento 002</li>
        <li>Elemento 003</li>
        <li>Elemento 004</li>
        <li>Elemento 005</li>
        <li>Elemento 006</li>
        <li>Elemento 007</li>
        <li>Elemento 008</li>
        <li>Elemento 009</li>
        <li>Elemento 010</li>
        <li>Elemento 011</li>
        <li>Elemento 012</li>
        <li>Elemento 013</li>
        <li>Elemento 014</li>
        <li>Elemento 015</li>
        <li>Elemento 016</li>
        <li>Elemento 017</li>
        <li>Elemento 018</li>
        <li>Elemento 019</li>
        <li>Elemento 020</li>
        <li>Elemento 021</li>
        <li>Elemento 022</li>
        <li>Elemento 023</li>
        <li>Elemento 024</li>
        <li>Elemento 025</li>
        <li>Elemento 026</li>
        <li>Elemento 027</li>
        <li>Elemento 028</li>
        <li>Elemento 029</li>
        <li>Elemento 030</li>
        <li>Elemento 031</li>
        <li>Elemento 032</li>
        <li>Elemento 033</li>
        <li>Elemento 034</li>
        <li>Elemento 035</li>
        <li>Elemento 036</li>
    </ol>
    </>
)
}
export default Cuadro4