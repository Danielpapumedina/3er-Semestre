import Cuadro1 from "./contenedor/Cuadro1"
import Cuadro2 from "./contenedor/Cuadro2"
import Cuadro3 from "./contenedor/Cuadro3"
import Cuadro4 from "./contenedor/Cuadro4"
import Cuadro5 from "./contenedor/Cuadro5"

const App = () => {

  return (
          <>
            
            <Cuadro1/>
            <br />
            <Cuadro2/>
            <br />
            <Cuadro3/>
            <br />
            <Cuadro4/>
            <br />
            <Cuadro5/>
          </>
        )

}



export default App
