import "../Style/Cuadro5.css"

const Cuadro5 = () => {
    return(
        <>
        <div className="cuad1">
            <div className="cuad2">
                <div className ="cuad3">
                    <h1>Dr sexo</h1>
                </div>
            </div>
        </div>
        </>
    )
}
export default Cuadro5