export function printName(name){
    console.log(name);
}

export const arrayTypes = [123, "abc", true, false]

const elecciones ={

}