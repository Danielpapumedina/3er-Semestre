import "../Style/cuadro1.css"


const Cuadro1 = () => { 
    return (
        <>
        <h1>Title</h1>
        <br />
        <div className="lorem">
        <fieldset className ="Background">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium accusantium ut neque eveniet totam voluptates minima, sapiente commodi suscipit libero nulla doloremque debitis natus officia quibusdam modi mollitia quis ab, sed voluptatum quisquam autem cumque ipsam. Consequatur modi, maiores natus amet praesentium ab, rerum, deserunt minus id dolorem obcaecati. Commodi sed asperiores soluta ea labore. Obcaecati maiores sunt laboriosam hic, saepe quaerat, perferendis natus, enim at tempore quisquam laborum! Explicabo aut quod nemo illum voluptatem nihil facilis rerum iste accusamus est, minima delectus temporibus similique! Odit reprehenderit magni est laboriosam officiis, inventore repellendus maxime voluptatum hic adipisci laudantium tempora obcaecati alias? Amet harum quod veritatis mollitia maxime deleniti odit, ducimus velit corporis quisquam aperiam voluptas consequuntur non, ex enim? Voluptatibus dicta iste ipsam voluptate perspiciatis amet quae a dolor sed delectus quaerat, velit enim modi temporibus. Distinctio doloribus hic id dolorem quis eligendi consectetur doloremque ea nemo cum iusto perspiciatis maxime obcaecati, est placeat aut iste repellendus incidunt quia officia nihil! Voluptas velit, sequi provident placeat voluptates aliquid ea officiis illo esse molestias fugit magnam quo veniam tempora quae iusto quis sit quam! Natus veritatis non totam illum iure! Eaque, autem vero quasi dignissimos doloribus blanditiis sint quas aperiam error.
        </fieldset>
        </div>
        </>
    )
   
}

export default Cuadro1 