import "../Style/Cuadro3.css"

const Cuadro3 = () => {
return(
<>
<div className = "cuadro">
        <p>Derecha</p>
        <p>Este cuadro esta a la derecha</p>
    </div>
</>

)

}
export default Cuadro3