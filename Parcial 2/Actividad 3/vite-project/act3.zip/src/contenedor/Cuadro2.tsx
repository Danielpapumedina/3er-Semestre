import "../Style/Cuadro2.css"

const Cuadro2 = () => {

return(
    <>
        <ul className ="elem2">
        <li>Elemento1</li>
        <li>Elemento2</li>
        <li>Elemento3</li>
        <li>Elemento4</li>
        <li>Elemento5</li>
        <li>Elemento6</li>
        <li>Elemento7</li>
        <li>Elemento8</li>
        <li>Elemento9</li>
        <li>Elemento10</li>
        <li>Elemento11</li>
        <li>Elemento12</li>
        </ul>
    </>
)
} 
export default Cuadro2